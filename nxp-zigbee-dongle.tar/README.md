# Ruff Application
Used to gather Zigbee device information, translate device command.

With a UDP server to interact with node-zigbee-console APP.

